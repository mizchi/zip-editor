import "./_pre.js";
import JSZip from "https://cdn.pika.dev/jszip";
import { render, h } from "https://cdn.pika.dev/preact";
import { useRef, useState, useEffect } from "https://cdn.pika.dev/preact/hooks";
import path from "https://cdn.pika.dev/path-browserify";

class ZipFileSystem {
  #_handler = null;
  #_zip = null;

  async ensureHandler() {
    if (this.#_handler == null) {
      const newHandler = await window.chooseFileSystemEntries();
      this.#_handler = newHandler;
    }
    return this.#_handler;
  }

  async load() {
    const handler = await this.ensureHandler();
    const file = await handler.getFile();
    const zip = await new JSZip().loadAsync(file);
    this.#_zip = zip;
  }

  async save() {
    const result = await this.#_zip.generateAsync({ type: "blob" });
    try {
      const handler = await this.ensureHandler();
      const writable = await handler.createWritable();
      await writable.write(result);
      await writable.close();
    } catch (err) {
      console.error(err);
    }
  }

  listFiles() {
    return Object.values(this.#_zip.files);
  }

  async readFile(fpath) {
    const relpath = this.resolveToZipPath(fpath);
    return await this.#_zip.file(relpath).async("string");
  }

  async writeFile(fpath, content) {
    const relpath = this.resolveToZipPath(fpath);
    await this.#_zip.file(relpath, content);
  }

  resolveToZipPath(fpath) {
    return path.relative("/", fpath);
  }
}

function App(props) {
  const ref = useRef(null);
  const [files, setFiles] = useState([]);
  const [text, setText] = useState(null);

  return h(
    "div",
    {},
    text != null &&
      h("textarea", {
        ref,
        value: text,
        onChange: async (ev) => {
          console.log("changed");
          setText(ev.target.value);
          const content = ref.current.value;
          await props.fs.writeFile("/hello.txt", content);
        },
        style: { width: "80vw", height: "60vh" },
      }),
    h(
      "div",
      {},
      h(
        "button",
        {
          disabled: text == null,
          async onClick() {
            const content = ref.current.value;
            setText(content);
            await props.fs.save();
          },
        },
        "save"
      ),
      h(
        "button",
        {
          async onClick() {
            await props.fs.load();
            const data = await props.fs.readFile("/hello.txt");
            const files = await props.fs.listFiles();
            setText(data);
            setFiles(files);
          },
        },
        "load"
      )
    )
  );
}

// async function writeFile(handler, contents) {
//   const writable = await handler.createWritable();
//   await writable.write(contents);
//   await writable.close();
// }

const fs = new ZipFileSystem();
render(h(App, { fs }), document.body);
