globalThis.global = globalThis;
